package org.milan.naucnacentrala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaucnaCentralaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaucnaCentralaApplication.class, args);
	}

}
